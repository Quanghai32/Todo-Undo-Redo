import { ActionReducer, Action, combineReducers } from '@ngrx/store';
import { VIEW_MODE, CREATE_MODE, EDIT_MODE, DETAIL_MODE } from '../state/app.state';
import { counterReducer,colorReducer } from '../counter'


 const ViewReducer: ActionReducer<any> = (state = VIEW_MODE, action) => {
    switch (action.type) {
        case 'CHANGE_VIEW':
            //alert(action.payload.viewMode);
            return action.payload.viewMode;
        default:
            return state;
    }
}

export const AppReducers = {
    ViewReducer,
    counterReducer,
    colorReducer
}