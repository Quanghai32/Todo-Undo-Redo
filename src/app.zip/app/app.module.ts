import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule }   from '@angular/forms';
import { StoreModule } from '@ngrx/store';
import { AppReducers } from './reducers/app.reducer';

import { AppComponent } from './app.component';
import { StoreDevtoolsModule } from '@ngrx/store-devtools';
import { CounterComponent } from './counter.component';
import { ChartModule } from 'angular-highcharts';
import { Ng2GoogleChartsModule } from 'ng2-google-charts';
import { MyDatePickerModule } from 'mydatepicker';



@NgModule({
  declarations: [
    AppComponent,
    CounterComponent
  ],
  imports: [
    FormsModule,
    BrowserModule,
    Ng2GoogleChartsModule,
    StoreModule.provideStore(AppReducers),
    StoreDevtoolsModule.instrumentOnlyWithExtension(),
    MyDatePickerModule 
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
