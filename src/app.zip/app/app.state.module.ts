export interface AppState {
    numberCounter: number;
    highlight: boolean;
}

