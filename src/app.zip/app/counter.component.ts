import { Component } from '@angular/core';
import { Store } from '@ngrx/store';
import { INCREMENT, DECREMENT, RESET } from './counter';
import { Observable } from 'rxjs/Observable'
import 'rxjs/add/observable/combineLatest';
import 'rxjs/add/observable/from';

interface count{
    counter:number;
    highlight:boolean;
}


@Component({
    selector: 'counter-app',
    template: `
    <div style="border-style: solid;border-width: 3px;">
        <button (click)="decrement()">Decrement</button>   
        <button (click)="increment()">Increment</button>
        <button (click)="reset()">Reset Counter</button>
        <div>Current count: {{ counter$ | async }}</div>   
        <button (click)="changeRed()">Red</button>
        <button (click)="changeBlue()">Blue</button>
        <div>Current color: {{ color$.color | async }}</div>   
    </div>   
    `
})

export class CounterComponent {
    myObject$: Observable<any>;
    counter$: Observable<number>;
    color$: Observable<string>;

    constructor(private store: Store<any>) {
        this.counter$ = store.select('counterReducer');
        this.color$ = store.select('colorReducer');

        console.log(this.counter$);

    }

    increment() {
        this.store.dispatch({ type: INCREMENT });
    }

    decrement() {
        this.store.dispatch({ type: DECREMENT });
    }

    reset() {
        this.store.dispatch({ type: RESET });
    }

    changeRed(){
        this.store.dispatch({type:'change',payload:{color:'hihi',id:0}})
    }
    changeBlue(){
        this.store.dispatch({type:'change',payload:{color:'hehe',id:0}})
    }
}