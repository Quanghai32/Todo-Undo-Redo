import { ActionReducer, Action, combineReducers } from '@ngrx/store';

//import { AppState } from './app.state.module';
export const INCREMENT = 'INCREMENT';
export const DECREMENT = 'DECREMENT';
export const RESET = 'RESET';

interface AppState {
	numberCounter: number;
	highlight: boolean;
}

const defaultState = { numberCounter: 0, highlight: false };

export const counterReducer: ActionReducer<number> = (state: number = 0, action: Action) => {
	switch (action.type) {
		case INCREMENT:
			return state + 1;

		case DECREMENT:
			return state - 1

		case RESET:
			return state = 0;

		default:
			return state;
	}
}

export const colorReducer: ActionReducer<any> = (state, action) => {
	switch (action.type) {
		case 'change':
			return {color:action.payload.color,id:action.payload.id};
		case 'RESET':
			return "";
		default:
			return state;
	}
}



export const appReducers = {
	counter: counterReducer,
	color: colorReducer
};
