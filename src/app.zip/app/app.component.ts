import { Component } from '@angular/core';
import { Store } from '@ngrx/store';
import { Chart } from 'angular-highcharts';

import { INCREMENT, DECREMENT, RESET } from './counter';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/observable/interval';
import * as Rx from 'rxjs';
import { VIEW_MODE, CREATE_MODE, EDIT_MODE, DETAIL_MODE } from './state/app.state';
import { ChartSelectEvent } from 'ng2-google-charts';
import { IMyDpOptions } from 'mydatepicker';


export enum ViewMode {
  viewList,
  viewCreate,
  viewEdit,
  viewDetail
}

export interface StandardCrudState {
  viewMode: ViewMode;
};

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})

export class AppComponent {
  enumViewMode$: Observable<string>;
  standardCrudState$: Observable<StandardCrudState>;

  test: Observable<any>;
  constructor(private store: Store<any>) {
    this.enumViewMode$ = store.select('ViewReducer');

    var value = Rx.Observable.of('a', 'b', 'c', 'd', 'e');
    var filter = Rx.Observable.of('1', '2', '3');
    value.subscribe(x => console.log('value ' + x));
    filter.subscribe(x => console.log('filter ' + x));
    var bmi = Rx.Observable.combineLatest(filter, value, (w, h) => w + h);
    bmi.subscribe(x => console.log('filter value ' + x));
    console.log('---------------------------------')
    var bmi = Rx.Observable.combineLatest(value, filter, (w, h) => w + h);
    bmi.subscribe(x => console.log('value filter ' + x));
    console.log('---------------------------------')
    this.test = value.combineLatest(filter, (w, h) => w + h);
    this.test.subscribe(x => console.log('test ' + x));
    console.log('---------------------------------')

    var source = Rx.Observable.range(0, 5)
      .filter((x) => x % 2 === 0);
    source.subscribe(x =>{

      console.log('filter ' + x)
    } );

  }
  viewList() {
    this.store.dispatch({ type: 'CHANGE_VIEW', payload: { viewMode: VIEW_MODE } });
  }

  create() {
    this.store.dispatch({ type: 'CHANGE_VIEW', payload: { viewMode: CREATE_MODE } });
  }

  detail() {
    this.store.dispatch({ type: 'CHANGE_VIEW', payload: { viewMode: DETAIL_MODE } });
  }

  edit() {
    this.store.dispatch({ type: 'CHANGE_VIEW', payload: { viewMode: EDIT_MODE } });
  }

  door: number;

  setDoor(num: number) {
    this.door = num;
  }

  tableHeader: Array<any> = ['Task', 'seri 1', 'seri2', { role: 'style' }];
  pieChartData = {
    chartType: 'ColumnChart',
    dataTable: [
      this.tableHeader,
      ['Work', 11, 2, 'silver'],
      ['Eat', 2, 3, 'red'],
      ['Commute', 2, 4, 'blue'],
      ['Watch TV', 2, 5, 'green'],
      ['Sleep', 7, 4, 'gray']
    ],
    options: {
      'title': 'Tasks',
      isStacked: true,
    },
  };

  public select(event: ChartSelectEvent) {
    this.store.dispatch({ type: 'CHANGE_VIEW', payload: { viewMode: event.selectedRowValues } });
  }

  public myDatePickerOptions: IMyDpOptions = {
    // other options...
    dateFormat: 'dd.mmm.yyyy',
  };

  // Initialized to specific date (09.10.2018).
  public fromDate: any = { date: { year: 2018, month: 10, day: 9 } };
  public toDate: any = { date: { year: 2018, month: 10, day: 12 } };

  number: number = 0;
  Increase() {
    this.number++;
  }

}
