export const VIEW_MODE="VIEW_MODE"
export const CREATE_MODE="CREATE_MODE"
export const DETAIL_MODE="DETAIL_MODE"
export const EDIT_MODE="EDIT_MODE"